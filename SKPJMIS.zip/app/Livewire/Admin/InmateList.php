<?php

namespace App\Livewire\Admin;

use App\Models\Inmate;
use App\Models\Shop\Product;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Illuminate\Contracts\View\View;
use Livewire\Component;

class InmateList extends Component implements HasForms, HasTable
{
    use InteractsWithTable;
    use InteractsWithForms;

    public $add_modal = false;

    public function table(Table $table): Table
    {
        return $table
            ->query(Inmate::query())->headerActions([
                Action::make('new')->label('New Inmates')->icon('heroicon-o-user-plus')->color('main')->url(fn (): string => route('admin.inmates-create'))
            ])
            ->columns([
                TextColumn::make('created_at')->date()->label('CREATED DATE')->searchable(),
                TextColumn::make('fullname')->label('NAME')->searchable(),
                TextColumn::make('status')->label('STATUS')->badge()->searchable()->formatStateUsing(
                    fn($record) => ucfirst($record->status)
                )->color(fn (string $state): string => match ($state) {
                    'pending' => 'warning',
                    'approved' => 'success',
                    'dismissed' => 'danger',
                }),
            ])
            ->filters([
                // ...
            ])
            ->actions([
                ActionGroup::make([
                    Action::make('view')->color('warning')->icon('heroicon-o-eye'),
                    Action::make('edit')->color('success')->icon('heroicon-o-pencil'),
                    DeleteAction::make('delete'),
                ])
            ])
            ->bulkActions([
                // ...
            ])->emptyStateHeading('No Inmates yet')->emptyStateDescription('Once you write your first inmate, it will appear here.');
    }

    public function render()
    {
        return view('livewire.admin.inmate-list');
    }
}
