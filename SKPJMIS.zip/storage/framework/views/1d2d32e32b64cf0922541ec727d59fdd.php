<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH E:\FREELANCE PROJECTS\SKPJMIS\resources\views/livewire/admin/inmate-list.blade.php ENDPATH**/ ?>