<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/dashboard', function () {
   switch (auth()->user()->user_type) {
    case 'admin':
        return redirect()->route('admin.dashboard');
        break;
    case 'staff':

        break;

    default:
        # code...
        break;
   }
})->middleware(['auth', 'verified'])->name('dashboard');

//admin routes
Route::prefix('admin')->group( function(){
    Route::get('dashboard', function () {
       return view('admin.dashboard');
    })->name('admin.dashboard');
    Route::get('inmates', function () {
       return view('admin.inmates');
    })->name('admin.inmates');
    Route::get('inmates/create', function () {
       return view('admin.inmates-create');
    })->name('admin.inmates-create');
    Route::get('crimes', function () {
       return view('admin.crimes');
    })->name('admin.crimes');
    Route::get('visitor', function () {
       return view('admin.visitor');
    })->name('admin.visitor');
    Route::get('cell-block', function () {
       return view('admin.cell');
    })->name('admin.cell');
});


//staff routes

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
