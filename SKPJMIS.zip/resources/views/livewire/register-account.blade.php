<div>
    <div>
        {{ $this->form }}
    </div>
    <div class="mt-10 flex justify-end">
        <x-button label="Create Account" dark />
    </div>
</div>
